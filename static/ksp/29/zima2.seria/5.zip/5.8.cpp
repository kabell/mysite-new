#include <iostream>
#include <string>
#include <stdlib.h>
#include <sstream>
#include <math.h>
#include <stdio.h>
using namespace std;


int main(){
    long pocet = 0;
    char c;
int err=0;
    while(scanf("%c", &c)!=EOF){
if(c=='<') cout<<" <";
else if(c=='&') cout<<" &";
else if(c=='>') cout<<"> ";
else if(c==';') cout<<"; ";
else cout<<c;


   } 
    

    cin.get();
    cin.get();
    
}

