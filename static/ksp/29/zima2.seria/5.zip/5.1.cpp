#include <iostream>
#include <string>
#include <stdlib.h>
#include <sstream>
#include <math.h>
#include <stdio.h>
using namespace std;


int main(){
    long pocet = 0;
    string slovo;
int err=0;
    while(cin>>slovo){

while(slovo.find('A')!=string::npos){
int pos=slovo.find('A');
slovo.replace(pos,1,"a");
}

while(slovo.find('B')!=string::npos){
int pos=slovo.find('B');
slovo.replace(pos,1,"b");
}
while(slovo.find('C')!=string::npos){
int pos=slovo.find('C');
slovo.replace(pos,1,"c");
}
while(slovo.find('D')!=string::npos){
int pos=slovo.find('D');
slovo.replace(pos,1,"d");
}
while(slovo.find('E')!=string::npos){
int pos=slovo.find('E');
slovo.replace(pos,1,"e");
}
while(slovo.find('F')!=string::npos){
int pos=slovo.find('F');
slovo.replace(pos,1,"f");
}
while(slovo.find('G')!=string::npos){
int pos=slovo.find('G');
slovo.replace(pos,1,"g");
}

while(slovo.find('H')!=string::npos){
int pos=slovo.find('H');
slovo.replace(pos,1,"h");
}
while(slovo.find('I')!=string::npos){
int pos=slovo.find('I');
slovo.replace(pos,1,"i");
}
while(slovo.find('J')!=string::npos){
int pos=slovo.find('J');
slovo.replace(pos,1,"j");
}
while(slovo.find('K')!=string::npos){
int pos=slovo.find('K');
slovo.replace(pos,1,"k");
}
while(slovo.find('L')!=string::npos){
int pos=slovo.find('L');
slovo.replace(pos,1,"l");
}
while(slovo.find('M')!=string::npos){
int pos=slovo.find('M');
slovo.replace(pos,1,"m");
}
while(slovo.find('N')!=string::npos){
int pos=slovo.find('N');
slovo.replace(pos,1,"n");
}
while(slovo.find('O')!=string::npos){
int pos=slovo.find('O');
slovo.replace(pos,1,"o");
}
while(slovo.find('P')!=string::npos){
int pos=slovo.find('P');
slovo.replace(pos,1,"p");
}
while(slovo.find('Q')!=string::npos){
int pos=slovo.find('Q');
slovo.replace(pos,1,"q");
}
while(slovo.find('R')!=string::npos){
int pos=slovo.find('R');
slovo.replace(pos,1,"r");
}
while(slovo.find('S')!=string::npos){
int pos=slovo.find('S');
slovo.replace(pos,1,"s");
}
while(slovo.find('T')!=string::npos){
int pos=slovo.find('T');
slovo.replace(pos,1,"t");
}
while(slovo.find('U')!=string::npos){
int pos=slovo.find('U');
slovo.replace(pos,1,"u");
}
while(slovo.find('V')!=string::npos){
int pos=slovo.find('V');
slovo.replace(pos,1,"v");
}
while(slovo.find('W')!=string::npos){
int pos=slovo.find('W');
slovo.replace(pos,1,"w");
}
while(slovo.find('X')!=string::npos){
int pos=slovo.find('X');
slovo.replace(pos,1,"x");
}
while(slovo.find('Y')!=string::npos){
int pos=slovo.find('Y');
slovo.replace(pos,1,"y");
}
while(slovo.find('Z')!=string::npos){
int pos=slovo.find('Z');
slovo.replace(pos,1,"z");
}




 cout<<slovo<<endl;
   } 
    

    cin.get();
    cin.get();
    
}
