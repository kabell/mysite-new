#include <iostream>
#include <string>
#include <stdlib.h>
#include <sstream>
#include <math.h>
#include <stdio.h>
using namespace std;


int main(){
    long pocet = 0;
    string slovo;
int err=0;
    while(cin>>slovo){

if(slovo.find_first_of("0123456789.,")==string::npos)
 cout<<slovo<<endl;
   } 
    

    cin.get();
    cin.get();
    
}
